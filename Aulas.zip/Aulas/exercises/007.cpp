#include <iostream>
#include <iomanip>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int main() {
    cleanScreen();

    float value;
    cout << "Enter the value: ";
    cin >> value;

    if (value > 100) {
        float descont = value / 100 * 10;
        float newValue = value - descont;
        value = newValue;
    }

    cout << "Final price: R$" << fixed << setprecision(2) << value << endl;

    return 0;
}