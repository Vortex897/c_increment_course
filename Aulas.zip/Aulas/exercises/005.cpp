#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int main() {
    cleanScreen();

    int n;
    cout << "Enter the number of lines: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        cout << i << endl;
    }

    return 0;
}