#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << "\n";
    }
}

int main() {
    cleanScreen();

    int commits;
    cout << "Enter the number of commits: ";
    cin >> commits;

    for (int i = 1; i <= commits; i++){
        cout << "commit #" << i << endl;
    }

    return 0;
}