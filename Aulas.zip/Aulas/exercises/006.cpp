#include <iostream>
#include <algorithm>
#include <cctype>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int main() {
    cleanScreen();

    string str;
    cout << "Enter the string: ";
    cin >> str;

    transform(str.begin(), str.end(), str.begin(),
        [](unsigned char c){ return tolower(c); });

    if (str.find("bug") != string::npos) {
        cout << "This string contain bug." << endl;
    } else {
        cout << "This string not contain bug." << endl;
    }

    return 0;
}