#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int workTime (int e, int s) {
    int total = s - e;

    if (total < 0) total += 24; 

    return total;
}

int main() {
    cleanScreen();

    int start;
    int end;

    cout << "Enter the start time: ";
    cin >> start;

    cout << "Enter the end time: ";
    cin >> end;

    int totalTime = workTime(start, end);
    cout << "Total work time: " << totalTime << "h" << endl;

    return 0;
}