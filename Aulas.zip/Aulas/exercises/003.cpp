#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

float validGrade(float n) {
    float grade = -1;

    while (grade < 0 or grade > 10 ) {
        cout << "\nEnter the grade " << n << " (0-10): ";
        cin >> grade;
    }

    return grade;
}

void result(float a1, float a2, float a3) {
    float r = (a1 + a2 + a3) / 3;

    if (r >= 7){
        cout << "\nAvarage: " << r << "\nApproved." << endl;
    } else {
        cout << "\nAvarage: " << r << "\nDisapproved." << endl;
    }
}

int main() {
    cleanScreen();

    float grade1 = validGrade(1);
    float grade2 = validGrade(2);
    float grade3 = validGrade(3);

    result(grade1, grade2, grade3);

    return 0;
}