#include <iostream>
#include <iomanip>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

float temperatureConverter(float f) {
    float c = (f - 32) * 5 / 9;

    return c;
}

int main() {
    cleanScreen();

    float f;
    cout << "Enter the fahrenheit temperature: ";
    cin >> f;

    float celsius = temperatureConverter(f);

    cout << "Celsius: " << fixed << setprecision(1) << celsius << "C" << endl;

    return 0;
}