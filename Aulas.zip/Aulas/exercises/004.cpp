#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

void validPassword(string password) {
    if (password == "1234") {
        cout << "Access allowed.";
    } else {
        cout << "Access denied. Invalid password.";
    }
}

int main() {
    cleanScreen();

    string password;
    cout << "Enter the password: ";
    cin >> password;

    validPassword(password);

    return 0;
}