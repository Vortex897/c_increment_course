#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int main() {
    cleanScreen();
    int numbers[5];
    int other_number = 4;

    numbers[0] = 10;
    numbers[1] = 20;
    numbers[2] = 30;
    numbers[3] = 40;
    numbers[4] = 50;

    for (int i = 0; i < 5; i++) {
        cout << "numbers[" << i <<"] = " << numbers[i] << endl;
    }

    cout << "\nnumbers[" << other_number << "] = " << numbers[other_number] << endl;

    return 0;
}