#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++){
        cout << "\n";
    }
}

int main() {
    cleanScreen();
    int num;

    cout << "Type a number of 1 to 4 to switch the season: ";
    cin >> num;

    switch (num) {
        case 1:
            cout << "Summer" << endl;
            break;
        case 2:
            cout << "Fall" << endl;
            break;
        case 3:
            cout << "Winter" << endl;
            break;
        case 4:
            cout << "Spring" << endl;
            break;
        default:
            cout << "Invalid number! Type of 1 to 4." << endl;
            break;
    }
    
    return 0;
}