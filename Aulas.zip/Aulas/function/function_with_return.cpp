#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

int sum(int a, int b) {
    return a + b;
}

int main() {
    cleanScreen();
    int x = 5, y = 3;
    int result = sum(x, y);
    cout << "Result of the sum: " << result << endl;
    return 0;
}