#include <iostream>

using namespace std;

void cleanScreen() {
    for (int i = 0; i < 100; i++) {
        cout << " \n";
    }
}

void greeting() {
    cout << "Hello, welcome to C++ course!" << endl;
}

int main(){
    cleanScreen();
    greeting();

    return 0;
}